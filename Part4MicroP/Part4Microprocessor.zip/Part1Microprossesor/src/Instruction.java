
public class Instruction {
	
	public int Opcode;
	public String InstructionName;
	
	public Instruction(int opcode, String instructionName)
	{
		Opcode = opcode;
		InstructionName= instructionName;
	}
}
