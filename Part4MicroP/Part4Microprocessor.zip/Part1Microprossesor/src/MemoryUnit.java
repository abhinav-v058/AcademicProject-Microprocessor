import javax.print.DocFlavor.STRING;

public class MemoryUnit {

	public int Address;
	public int Value;
	
	public MemoryUnit(int address, int value)
	{
		Address= address;
		Value = value;
	}
}
